package com.tbreak.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
